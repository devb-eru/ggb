$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-ep02-boundary-run-20261105.json') -Raw|ConvertFrom-Json
$root=Join-Path $env:TEMP ('ggb-ep02-regress-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root|Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $root 'runner.ps1')
function Assert-Source {foreach($f in $source.source_files){if((Get-FileHash -LiteralPath (Join-Path $source.project $f.path)).Hash.ToLowerInvariant() -cne $f.sha256){throw ('Source changed '+$f.path)}}}
Assert-Source
$meta=@{root=$root;source=$source}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot '.tmp-notebook-ep02-boundary-regress-20261105.json'),($meta|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
$oldApp=$env:APPDATA;$oldLocal=$env:LOCALAPPDATA;$p=$null
try{
    foreach($spec in @(@('sheet','sheet','sheet_sync_smoke.tscn',@()),@('ep01','ep01','ep01_sheet_smoke.tscn',@()),@('modal-seed','modal','',@('--notebook-modal-presentation-smoke','--cursor-phase=seed')),@('modal-resume','modal','',@('--notebook-modal-presentation-smoke','--cursor-phase=resume')),@('modal-completed','modal','',@('--notebook-modal-presentation-smoke','--cursor-phase=completed')),@('campaign','campaign','',@('--full-campaign-smoke')))){
        $name=$spec[0];$group=Join-Path $root $spec[1]
        $env:APPDATA=Join-Path $group 'appdata';$env:LOCALAPPDATA=Join-Path $group 'localappdata'
        New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA -Force|Out-Null
        $argsList=@('--headless','--path',('"'+$source.project+'"'))
        if($spec[2]){$argsList+=('res://scripts/tests/'+$spec[2])}
        $argsList+=@('--','--ggb-dev-full','--ggb-dev-notebook-v2','--notebook-require-authored')+@($spec[3])
        $out=Join-Path $root ($name+'.out.log');$err=Join-Path $root ($name+'.err.log');$started=[DateTime]::UtcNow.ToString('o')
        $p=Start-Process -FilePath $source.engine -ArgumentList $argsList -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
        Write-Output ($name+' PID='+$p.Id)
        $done=$false;$scriptError=$false
        for($tick=0;$tick -lt 900;$tick++){
            if($p.WaitForExit(1000)){$done=$true;break}
            if((Get-Content -LiteralPath $err -Raw) -match 'SCRIPT ERROR:|Parse Error:'){$scriptError=$true;break}
        }
        if(-not $done){$p.Kill();$p.WaitForExit()}
        $receipt=@{name=$name;completed=$done;script_error=$scriptError;exit_code=$p.ExitCode;pid=$p.Id;arguments=$argsList;started_utc=$started;finished_utc=[DateTime]::UtcNow.ToString('o');source=$source;stdout_sha256=(Get-FileHash -LiteralPath $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath $err).Hash.ToLowerInvariant()}
        [IO.File]::WriteAllText((Join-Path $root ($name+'.json')),($receipt|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
        Get-Content -LiteralPath $err -Tail 10
        Get-Content -LiteralPath $out -Tail 4
        if(-not $done -or $p.ExitCode -ne 0){throw ('Regression failed '+$name+'; '+$root)}
    }
    Assert-Source
    Write-Output ('REGRESSION_DONE '+$root)
}finally{if($null -ne $p -and -not $p.HasExited){$p.Kill();$p.WaitForExit()};$env:APPDATA=$oldApp;$env:LOCALAPPDATA=$oldLocal}
