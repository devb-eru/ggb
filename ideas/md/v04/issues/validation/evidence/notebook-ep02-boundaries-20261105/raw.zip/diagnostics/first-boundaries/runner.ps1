$ErrorActionPreference='Stop'
$gui=Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-windows-sleep-20261105.json') -Raw|ConvertFrom-Json
$previous=Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-late-modal-candidate-20261105.json') -Raw|ConvertFrom-Json
$project=$previous.project
if(-not $project.StartsWith((Join-Path $env:TEMP 'ggb-modal-candidate-'),[StringComparison]::OrdinalIgnoreCase)){throw 'Expected owned candidate project'}
$root=Join-Path $env:TEMP ('ggb-ep02-boundary-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root|Out-Null
$mirror=Join-Path $PSScriptRoot '.tmp-notebook-sheet-20261103'
foreach($name in @('notebook_ep02_modal_boundaries.gd','notebook_ep02_modal_boundaries.tscn')){Copy-Item -LiteralPath (Join-Path $mirror ('game/scripts/tests/'+$name)) -Destination (Join-Path $project ('scripts/tests/'+$name))}
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $root 'runner.ps1')
$sources=@(Get-ChildItem -LiteralPath (Join-Path $project 'scripts') -Recurse -File -Filter '*.gd'|ForEach-Object{@{path=[IO.Path]::GetRelativePath($project,$_.FullName).Replace('\','/');sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}}|Sort-Object path)
$meta=@{root=$root;project=$project;engine=$gui.engine;base_commit='f8aada719409238f6dd54a269c749c36df363ba4';source_files=$sources;scope='EP02 modal save boundaries; not OS input or full acceptance'}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot '.tmp-notebook-ep02-boundary-run-20261105.json'),($meta|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
$oldApp=$env:APPDATA;$oldLocal=$env:LOCALAPPDATA;$p=$null
try{
    $env:APPDATA=Join-Path $root 'appdata';$env:LOCALAPPDATA=Join-Path $root 'localappdata'
    New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA|Out-Null
    $arguments=@('--headless','--path',('"'+$project+'"'),'res://scripts/tests/notebook_ep02_modal_boundaries.tscn','--','--ggb-dev-notebook-v2','--notebook-require-authored')
    $out=Join-Path $root 'run.out.log';$err=Join-Path $root 'run.err.log';$started=[DateTime]::UtcNow.ToString('o')
    $p=Start-Process -FilePath $gui.engine -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    Write-Output ('EP02_BOUNDARY PID='+$p.Id)
    $done=$p.WaitForExit(900000)
    if(-not $done){$p.Kill();$p.WaitForExit()}
    $receipt=@{completed=$done;exit_code=$p.ExitCode;pid=$p.Id;arguments=$arguments;started_utc=$started;finished_utc=[DateTime]::UtcNow.ToString('o');meta=$meta;stdout_sha256=(Get-FileHash -LiteralPath $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath $err).Hash.ToLowerInvariant()}
    [IO.File]::WriteAllText((Join-Path $root 'run.json'),($receipt|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
    Get-Content -LiteralPath $err -Tail 30
    Get-Content -LiteralPath $out -Tail 15
    if(-not $done -or $p.ExitCode -ne 0){throw ('Boundary run failed; evidence '+$root)}
}finally{if($null -ne $p -and -not $p.HasExited){$p.Kill();$p.WaitForExit()};$env:APPDATA=$oldApp;$env:LOCALAPPDATA=$oldLocal}
