param([ValidateSet('mirror','basic','sheet','campaign','inventory')][string]$Mode='mirror')
$ErrorActionPreference='Stop'
$r=Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-sheet-run-20261103.json') -Raw|ConvertFrom-Json
$project=$r.candidate
$evidence=Join-Path $r.root ('latest-regression-'+$Mode)
if(Test-Path -LiteralPath $evidence){throw 'Evidence exists'}
New-Item -ItemType Directory -Path $evidence|Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $evidence 'runner.ps1')
function Corpus([string]$Directory,[string]$Filter){@(Get-ChildItem -LiteralPath (Join-Path $project $Directory) -Filter $Filter -Recurse -File|Sort-Object FullName|ForEach-Object {$_.FullName.Substring($project.Length+1).Replace('\','/')+"`t"+(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()})}
$source=Corpus 'scripts' '*.gd';$data=Corpus 'data' '*'
$suite=@{mirror='notebook_mirror_smoke';basic='black_mirror_smoke';campaign='full_campaign_smoke';inventory='inventory_hud_smoke'}[$Mode]
$argsList=@('--headless','--verbose','--path',('"'+$project+'"'))
if($Mode -eq 'sheet'){$argsList+=@('res://scripts/tests/sheet_sync_smoke.tscn','--','--ggb-dev-notebook-v2','--notebook-require-authored')}
else{$argsList+=@('res://scripts/tests/sheet_sync_regression.tscn','--',('--sheet-regression='+$suite),'--ggb-dev-notebook-v2','--notebook-require-authored')}
$out=Join-Path $evidence 'run.out.log';$err=Join-Path $evidence 'run.err.log';$oldApp=$env:APPDATA;$oldLocal=$env:LOCALAPPDATA;$p=$null
try{
    $env:APPDATA=Join-Path $evidence 'appdata';$env:LOCALAPPDATA=Join-Path $evidence 'localappdata'
    New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA|Out-Null
    $started=[DateTime]::UtcNow.ToString('o')
    $p=Start-Process -FilePath $r.engine -ArgumentList $argsList -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    Write-Output ('LATEST_REGRESSION '+$Mode+' PID='+$p.Id)
    $finished=$p.WaitForExit(1800000)
    if(-not $finished){$p.Kill();$p.WaitForExit()}
    $sourceUnchanged=[string]::Join("`n",$source) -ceq [string]::Join("`n",(Corpus 'scripts' '*.gd'))
    $dataUnchanged=[string]::Join("`n",$data) -ceq [string]::Join("`n",(Corpus 'data' '*'))
    $receipt=@{completed=$finished;exit_code=$p.ExitCode;pid=$p.Id;mode=$Mode;arguments=$argsList;started_utc=$started;finished_utc=[DateTime]::UtcNow.ToString('o');source_corpus=@{file_count=$source.Count;rows=$source};data_corpus=@{file_count=$data.Count;rows=$data};source_unchanged=$sourceUnchanged;data_unchanged=$dataUnchanged;engine_sha256=(Get-FileHash -LiteralPath $r.engine).Hash.ToLowerInvariant();runner_sha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash.ToLowerInvariant();stdout_sha256=(Get-FileHash -LiteralPath $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath $err).Hash.ToLowerInvariant()}
    [IO.File]::WriteAllText((Join-Path $evidence 'run.json'),($receipt|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
    if(-not $finished -or $null -eq $p.ExitCode -or $p.ExitCode -ne 0 -or -not $sourceUnchanged -or -not $dataUnchanged -or (Select-String -LiteralPath $out,$err -Pattern 'SCRIPT ERROR|Parse Error|Compile Error|ObjectDB instances leaked|resources still in use' -Quiet)){throw ('Regression failed: '+$Mode)}
    $lines=@(Get-Content -LiteralPath $out)
    if($Mode -eq 'sheet'){
        $summary=@($lines|Where-Object {$_ -match '^SHEET_SYNC_SMOKE PASS checks=\d+ failures=0$'})
        if($summary.Count -ne 1){throw 'Sheet result missing'}
        $summary
    }else{
        if(@($lines|Where-Object {$_ -ceq 'SHEET_REGRESSION PASS'}).Count -ne 1){throw 'Regression PASS missing'}
        $lines|Where-Object {$_.StartsWith('SHEET_REGRESSION '+$suite+' ')}
    }
}finally{if($null -ne $p -and -not $p.HasExited){$p.Kill();$p.WaitForExit()};$env:APPDATA=$oldApp;$env:LOCALAPPDATA=$oldLocal}
