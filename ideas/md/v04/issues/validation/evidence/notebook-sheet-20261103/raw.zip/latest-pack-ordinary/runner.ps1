param([switch]$Ordinary)
$ErrorActionPreference='Stop'
$r=Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-sheet-run-20261103.json') -Raw|ConvertFrom-Json
$pack=Join-Path $r.root 'latest-pack-catalog/candidate.pck'
$e=Join-Path $r.root $(if($Ordinary){'latest-pack-ordinary'}else{'latest-pack-runtime'})
if(Test-Path -LiteralPath $e){throw 'Packed runtime evidence already exists'}
New-Item -ItemType Directory -Path $e|Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $e 'runner.ps1')
$out=Join-Path $e 'run.out.log';$err=Join-Path $e 'run.err.log'
$oldApp=$env:APPDATA;$oldLocal=$env:LOCALAPPDATA;$p=$null
$packSha=(Get-FileHash -LiteralPath $pack).Hash.ToLowerInvariant()
try{
    $env:APPDATA=Join-Path $e 'appdata';$env:LOCALAPPDATA=Join-Path $e 'localappdata'
    New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA|Out-Null
    $argsList=if($Ordinary){@('--headless','--verbose','--main-pack',('"'+$pack+'"'),'--','--black-mirror-smoke')}else{@('--headless','--verbose','--main-pack',('"'+$pack+'"'),'res://scripts/tests/sheet_sync_regression.tscn','--','--sheet-regression=black_mirror_smoke','--ggb-dev-notebook-v2','--notebook-require-authored')}
    $start=[DateTime]::UtcNow.ToString('o')
    $p=Start-Process -FilePath $r.engine -ArgumentList $argsList -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    Write-Output ('PACK_RUNTIME PID='+$p.Id)
    $done=$p.WaitForExit(1200000)
    if(-not $done){$p.Kill();$p.WaitForExit()}
    $receipt=[ordered]@{completed=$done;exit_code=$p.ExitCode;pid=$p.Id;ordinary=[bool]$Ordinary;arguments=$argsList;started_utc=$start;finished_utc=[DateTime]::UtcNow.ToString('o');engine_sha256=(Get-FileHash -LiteralPath $r.engine).Hash.ToLowerInvariant();pack_sha256=$packSha;pack_unchanged=($packSha -ceq (Get-FileHash -LiteralPath $pack).Hash.ToLowerInvariant());runner_sha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash.ToLowerInvariant();stdout_sha256=(Get-FileHash -LiteralPath $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath $err).Hash.ToLowerInvariant()}
    [IO.File]::WriteAllText((Join-Path $e 'run.json'),($receipt|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
    if(-not $done -or $p.ExitCode -ne 0 -or -not $receipt.pack_unchanged -or (Select-String -LiteralPath $out,$err -Pattern 'SCRIPT ERROR|Parse Error|Compile Error|ObjectDB instances leaked|resources still in use|^ERROR:' -Quiet)){throw 'Packed runtime regression failed'}
    $lines=@(Get-Content -LiteralPath $out)
    $marker=if($Ordinary){'BLACK_MIRROR_SMOKE: PASS'}else{'SHEET_REGRESSION PASS'}
    if(@($lines|Where-Object {$_ -ceq $marker}).Count -ne 1){throw 'Packed runtime PASS missing'}
    $lines|Where-Object {$_ -ceq $marker -or $_.StartsWith('SHEET_REGRESSION black_mirror_smoke ')}
}finally{if($null -ne $p -and -not $p.HasExited){$p.Kill();$p.WaitForExit()};$env:APPDATA=$oldApp;$env:LOCALAPPDATA=$oldLocal}
