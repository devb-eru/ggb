extends SceneTree

func _initialize() -> void:
	var corpus_path := ""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--corpus="):
			corpus_path = argument.trim_prefix("--corpus=")
	var rows: Variant = JSON.parse_string(FileAccess.get_file_as_string(corpus_path))
	if not rows is Array or rows.size() != 50:
		printerr("PACK_CATALOG_CORPUS_INVALID")
		quit(1)
		return
	for row in rows:
		var parts := String(row).split("\t")
		if parts.size() != 2 or FileAccess.get_sha256("res://" + parts[0]) != parts[1]:
			printerr("PACK_CATALOG_MISMATCH: ", row)
			quit(1)
			return
	var definition: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/notebook/mirror_disclosure_v2.json"))
	if not definition is Dictionary or not definition.get("contents", {}).get("NB_MIRROR_NOTE_C5_INFO", {}).has("2"):
		printerr("PACK_C5_VERSION_MISSING")
		quit(1)
		return
	var c4: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/notebook/ep02_c4_confirmation_v2.json"))
	if not c4 is Dictionary or c4.get("contents", {}).size() != 8:
		printerr("PACK_C4_CONFIRMATION_MISSING")
		quit(1)
		return
	print("PACK_NOTEBOOK_CATALOGS_PASS json_files=50 C5_version=2 C4_confirmation=2")
	quit(0)
