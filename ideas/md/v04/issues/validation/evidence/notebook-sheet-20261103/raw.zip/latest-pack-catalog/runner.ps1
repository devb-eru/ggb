$ErrorActionPreference='Stop'
$r=Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-sheet-run-20261103.json') -Raw|ConvertFrom-Json
$engineSha=(Get-FileHash -LiteralPath $r.engine).Hash.ToLowerInvariant()
if($engineSha -cne $r.engine_sha256){throw 'Engine fingerprint changed'}
$e=Join-Path $r.root 'latest-pack-catalog'
if(Test-Path -LiteralPath $e){throw 'Pack evidence already exists'}
New-Item -ItemType Directory -Path $e|Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $e 'runner.ps1')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot '.tmp-notebook-sheet-pack-check-20261105.gd') -Destination (Join-Path $e 'catalog_check.gd')
$rows=@(Get-ChildItem -LiteralPath (Join-Path $r.candidate 'data') -Recurse -File -Filter '*.json'|Sort-Object FullName|ForEach-Object {$_.FullName.Substring($r.candidate.Length+1).Replace('\','/')+"`t"+(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()})
[IO.File]::WriteAllText((Join-Path $e 'catalog-corpus.json'),($rows|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
$oldApp=$env:APPDATA;$oldLocal=$env:LOCALAPPDATA;$p=$null
try{
    $env:APPDATA=Join-Path $e 'appdata';$env:LOCALAPPDATA=Join-Path $e 'localappdata'
    New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA|Out-Null
    $pack=Join-Path $e 'candidate.pck'
    foreach($mode in @('export','check')){
        $out=Join-Path $e ($mode+'.out.log');$err=Join-Path $e ($mode+'.err.log')
        $argsList=if($mode -ceq 'export'){@('--headless','--path',('"'+$r.candidate+'"'),'--export-pack','"Windows Desktop Debug"',('"'+$pack+'"'))}else{@('--headless','--main-pack',('"'+$pack+'"'),'--script',('"'+(Join-Path $e 'catalog_check.gd')+'"'),'--',('--corpus="'+(Join-Path $e 'catalog-corpus.json')+'"'))}
        $start=[DateTime]::UtcNow.ToString('o')
        $p=Start-Process -FilePath $r.engine -ArgumentList $argsList -PassThru -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err
        $done=$p.WaitForExit(600000)
        if(-not $done){$p.Kill();$p.WaitForExit()}
        $receipt=@{completed=$done;exit_code=$p.ExitCode;pid=$p.Id;arguments=$argsList;started_utc=$start;finished_utc=[DateTime]::UtcNow.ToString('o');engine_sha256=$engineSha;runner_sha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash.ToLowerInvariant();harness_sha256=(Get-FileHash -LiteralPath (Join-Path $e 'catalog_check.gd')).Hash.ToLowerInvariant();stdout_sha256=(Get-FileHash -LiteralPath $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath $err).Hash.ToLowerInvariant()}
        [IO.File]::WriteAllText((Join-Path $e ($mode+'.run.json')),($receipt|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
        if(-not $done -or $p.ExitCode -ne 0 -or (Select-String -LiteralPath $out,$err -Pattern 'SCRIPT ERROR|Parse Error|Compile Error' -Quiet)){throw ('Packed catalogue '+$mode+' failed')}
        if($mode -ceq 'check' -and -not (Select-String -LiteralPath $out -SimpleMatch 'PACK_NOTEBOOK_CATALOGS_PASS json_files=50 C5_version=2 C4_confirmation=2' -Quiet)){throw 'Packed catalogue marker missing'}
    }
    [ordered]@{ok=$true;pack_sha256=(Get-FileHash -LiteralPath $pack).Hash.ToLowerInvariant();json_files=$rows.Count;C5_version=2}|ConvertTo-Json
}finally{if($null -ne $p -and -not $p.HasExited){$p.Kill();$p.WaitForExit()};$env:APPDATA=$oldApp;$env:LOCALAPPDATA=$oldLocal}
