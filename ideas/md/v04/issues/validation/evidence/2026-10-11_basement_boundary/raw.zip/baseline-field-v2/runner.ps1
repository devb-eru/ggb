param([ValidateSet('baseline','candidate')][string]$Revision='baseline',[ValidateSet('scroll','field','full')][string]$Mode='scroll',[ValidateSet('ordinary','v2')][string]$Notebook='ordinary',[string]$Label='')
$ErrorActionPreference='Stop'
$r=Get-Content (Join-Path $PSScriptRoot '.tmp-basement-boundary-run.json') -Raw|ConvertFrom-Json
$project=$r.$Revision
if(-not $Label){$Label=$Revision+'-'+$Mode+'-'+$Notebook}
$evidence=Join-Path $r.root $Label
if(Test-Path -LiteralPath $evidence){throw 'Evidence path exists'}
New-Item -ItemType Directory -Path $evidence|Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $evidence 'runner.ps1')
$harness=''
if($Mode -eq 'scroll'){
    $harness=Join-Path $project '__boundary/notebook_legacy_scroll_lifetime.gd'
    [IO.Directory]::CreateDirectory((Split-Path -Parent $harness))|Out-Null
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot '.tmp-test-transfer-20261001/scripts/tests/notebook_legacy_scroll_lifetime.gd') -Destination $harness
    Copy-Item -LiteralPath $harness -Destination (Join-Path $evidence 'harness.gd')
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot '.tmp-test-transfer-20261001/scripts/tests/notebook_legacy_scroll_lifetime.tscn') -Destination (Join-Path $project '__boundary/notebook_legacy_scroll_lifetime.tscn')
    Copy-Item -LiteralPath (Join-Path $project '__boundary/notebook_legacy_scroll_lifetime.tscn') -Destination (Join-Path $evidence 'harness.tscn')
}
$rows=@(Get-ChildItem -LiteralPath (Join-Path $project 'scripts') -Recurse -Filter '*.gd' -File|Sort-Object FullName|ForEach-Object {$_.FullName.Substring($project.Length+1).Replace('\','/')+"`t"+(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()})
$args=@('--headless','--verbose','--path',('"'+$project+'"'))
if($Mode -eq 'scroll'){$args+='res://__boundary/notebook_legacy_scroll_lifetime.tscn'}
else{$args+=@('--','--basement-session-smoke');if($Mode -eq 'field'){$args+='--basement-field-regression-only'};if($Notebook -eq 'v2'){$args+=@('--ggb-dev-notebook-v2','--notebook-require-authored')}}
$out=Join-Path $evidence 'run.out.log';$err=Join-Path $evidence 'run.err.log'
$oldApp=$env:APPDATA;$oldLocal=$env:LOCALAPPDATA;$child=$null
try{
    $env:APPDATA=Join-Path $evidence 'appdata';$env:LOCALAPPDATA=Join-Path $evidence 'localappdata'
    New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA|Out-Null
    $started=[DateTime]::UtcNow.ToString('o')
    $child=Start-Process -FilePath $r.engine -ArgumentList $args -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    $finished=$child.WaitForExit($(if($Mode -eq 'scroll'){30000}else{1200000}))
    if(-not $finished){$child.Kill();$child.WaitForExit()}
    $after=@(Get-ChildItem -LiteralPath (Join-Path $project 'scripts') -Recurse -Filter '*.gd' -File|Sort-Object FullName|ForEach-Object {$_.FullName.Substring($project.Length+1).Replace('\','/')+"`t"+(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()})
    $receipt=@{base=$r.head;revision=$Revision;mode=$Mode;notebook=$Notebook;arguments=$args;pid=$child.Id;started_utc=$started;ended_utc=[DateTime]::UtcNow.ToString('o');completed=$finished;exit_code=$child.ExitCode;source_corpus=@{file_count=$rows.Count;rows=$rows};source_unchanged=([string]::Join("`n",$rows) -ceq [string]::Join("`n",$after));engine_sha256=(Get-FileHash -LiteralPath $r.engine).Hash.ToLowerInvariant();stdout_sha256=(Get-FileHash -LiteralPath $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath $err).Hash.ToLowerInvariant();harness_sha256=if($harness){(Get-FileHash -LiteralPath $harness).Hash.ToLowerInvariant()}else{''}}
    [IO.File]::WriteAllText((Join-Path $evidence 'run.json'),($receipt|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
    [pscustomobject]@{evidence=$evidence;exit=$child.ExitCode;completed=$finished;source_unchanged=$receipt.source_unchanged}|ConvertTo-Json
}finally{if($null -ne $child -and -not $child.HasExited){$child.Kill();$child.WaitForExit()};$env:APPDATA=$oldApp;$env:LOCALAPPDATA=$oldLocal}
