param([switch]$Candidate)
$ErrorActionPreference='Stop'
$gui=Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-windows-sleep-20261105.json') -Raw|ConvertFrom-Json
$project=Join-Path $PSScriptRoot '.tmp-notebook-layout-candidate-20261105'
if($Candidate){Copy-Item -LiteralPath (Join-Path $PSScriptRoot '.tmp-notebook-sheet-20261103/game/scripts/prologue/prologue_controller.gd') -Destination (Join-Path $project 'scripts/prologue/prologue_controller.gd')}
$root=Join-Path $env:TEMP ('ggb-drag-feedback-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root|Out-Null
Compress-Archive -LiteralPath (Join-Path $project 'scripts') -DestinationPath (Join-Path $root 'source_scripts.zip')
$source=@(Get-ChildItem (Join-Path $project 'scripts') -Recurse -File -Filter '*.gd'|ForEach-Object{@{path=[IO.Path]::GetRelativePath($project,$_.FullName).Replace('\','/');sha256=(Get-FileHash $_.FullName).Hash.ToLowerInvariant()}}|Sort-Object path)
Copy-Item $PSCommandPath (Join-Path $root 'runner.ps1')
$oldApp=$env:APPDATA;$oldLocal=$env:LOCALAPPDATA;$p=$null
try{
    $env:APPDATA=Join-Path $root 'appdata';$env:LOCALAPPDATA=Join-Path $root 'localappdata'
    New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA|Out-Null
    $out=Join-Path $root 'run.out.log';$err=Join-Path $root 'run.err.log'
    $args=@('--headless','--path',('"'+$project+'"'),'res://scripts/tests/inventory_drag_feedback_smoke.tscn')
    $p=Start-Process -FilePath $gui.engine -ArgumentList $args -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    $done=$false;$parse=$false
    for($i=0;$i -lt 120;$i++){
        if($p.WaitForExit(1000)){$done=$true;break}
        if((Get-Content $err -Raw) -match 'SCRIPT ERROR:|Parse Error:'){$parse=$true;break}
    }
    if(-not $done){$p.Kill();$p.WaitForExit()}
    $receipt=@{candidate=[bool]$Candidate;root=$root;completed=$done;parse_error=$parse;pid=$p.Id;exit_code=$p.ExitCode;source_files=$source;stdout_sha256=(Get-FileHash $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash $err).Hash.ToLowerInvariant()}
    [IO.File]::WriteAllText((Join-Path $root 'run.json'),($receipt|ConvertTo-Json -Depth 6).Replace("`r`n","`n"),[Text.UTF8Encoding]::new($false))
    Add-Content (Join-Path $PSScriptRoot '.tmp-notebook-drag-feedback-runs-20261105.txt') $root
    $receipt|Select-Object root,completed,parse_error,exit_code,pid|ConvertTo-Json
    Get-Content $out -Tail 8;Get-Content $err -Tail 20
}finally{if($p -and -not $p.HasExited){$p.Kill();$p.WaitForExit()};$env:APPDATA=$oldApp;$env:LOCALAPPDATA=$oldLocal}
