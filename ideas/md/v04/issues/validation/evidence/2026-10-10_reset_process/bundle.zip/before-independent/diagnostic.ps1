param([string]$OutputPath)
$ErrorActionPreference='Stop'
$r=Get-Content (Join-Path $PSScriptRoot '.tmp-reset-process-run.json') -Raw | ConvertFrom-Json
$matrix=Get-Content (Join-Path $r.root 'all/batch.json') -Raw | ConvertFrom-Json
$diffs=[Collections.Generic.List[object]]::new()
function Compare-Value($a,$b,[string]$path){
    if($a -is [Collections.IDictionary] -and $b -is [Collections.IDictionary]){
        if($a.Count -ne $b.Count){$diffs.Add(@{path=$path;kind='map_count'});return}
        foreach($key in $a.Keys){if(-not $b.Contains($key)){$diffs.Add(@{path=$path+'/'+$key;kind='missing'})}else{Compare-Value $a[$key] $b[$key] ($path+'/'+$key)}}
        return
    }
    if($a -is [array] -and $b -is [array]){
        if($a.Count -ne $b.Count){$diffs.Add(@{path=$path;kind='array_count'});return}
        for($i=0;$i -lt $a.Count;$i++){Compare-Value $a[$i] $b[$i] ($path+'/'+$i)}
        return
    }
    if(($a | ConvertTo-Json -Depth 100 -Compress) -cne ($b | ConvertTo-Json -Depth 100 -Compress)){
        $diffs.Add(@{path=$path;kind='scalar';a=$a;b=$b;a_type=$(if($null -eq $a){'null'}else{$a.GetType().Name});b_type=$(if($null -eq $b){'null'}else{$b.GetType().Name});numeric_equal=($a -is [ValueType] -and $b -is [ValueType] -and $a -eq $b)})
    }
}
foreach($case in $matrix.completed){
    $root=Join-Path $r.root ('all/'+$case.name+'/case')
    $a=Get-Content (Join-Path $root 'resumed_snapshot.json') -Raw | ConvertFrom-Json -AsHashtable
    $b=Get-Content (Join-Path $root 'verified_snapshot.json') -Raw | ConvertFrom-Json -AsHashtable
    Compare-Value $a $b $case.name
}
$result=@{differences=$diffs.Count;groups=@($diffs | Group-Object kind | Select-Object Name,Count);samples=@($diffs | Select-Object -First 12);non_numeric=@($diffs | Where-Object {-not $_.numeric_equal}).Count;all_differences=@($diffs)}
if($OutputPath){[IO.File]::WriteAllText([IO.Path]::GetFullPath($OutputPath),($result | ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))}
$result | Select-Object -Property differences,non_numeric | ConvertTo-Json
