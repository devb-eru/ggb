param([ValidateSet('probe','p6','all')][string]$Matrix='probe',[string]$Label='matrix')
$ErrorActionPreference='Stop'
$r=Get-Content (Join-Path $PSScriptRoot '.tmp-reset-process-run.json') -Raw | ConvertFrom-Json
$runner=Join-Path $PSScriptRoot '.tmp-test-transfer-20261001/scripts/run_notebook_reset_process_audit.ps1'
$points=@('sleep_confirmed','player_committed','memory_committed','physical_reset_complete','morning_loaded','route_selected','complete','idle')
$rows=@()
if($Matrix -eq 'probe'){
    foreach($route in @('chapter','mirror','basement','bedroom','capsule','rest')){
        $rows+=@{route=$route;point=if($route -eq 'rest'){'wake'}else{'idle'};cut='promoted';locale='ko_KR'}
        $rows+=@{route=$route;point='wake';cut='prepared';locale='en_US'}
    }
}else{
    $routes=if($Matrix -eq 'p6'){@('p6')}else{@('p6','chapter','mirror','basement','bedroom','capsule')}
    foreach($route in $routes){foreach($locale in @('ko_KR','en_US')){
        foreach($point in $points){$rows+=@{route=$route;point=$point;cut='promoted';locale=$locale}}
        $rows+=@{route=$route;point='physical_reset_complete';cut='prepared';locale=$locale}
    }}
    if($Matrix -eq 'all'){
        foreach($route in @('chapter','mirror','basement','bedroom','capsule','rest')){foreach($locale in @('ko_KR','en_US')){foreach($cut in @('prepared','promoted')){
            $rows+=@{route=$route;point='wake';cut=$cut;locale=$locale}
        }}}
    }
}
$root=Join-Path $r.root $Label
if(Test-Path -LiteralPath $root){throw 'Batch evidence already exists'}
New-Item -ItemType Directory -Path $root | Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $root 'batch.ps1')
$completed=@()
$failure=''
try{
    foreach($row in $rows){
        $name=$row.route+'-'+$row.point+'-'+$row.cut+'-'+$row.locale
        $path=Join-Path $root $name
        foreach($phase in @('seed','resume','verify')){
            $locale=if($phase -eq 'resume'){if($row.locale -eq 'ko_KR'){'en_US'}else{'ko_KR'}}else{$row.locale}
            & $runner -Phase $phase -Route $row.route -Point $row.point -Cut $row.cut -Locale $locale -SharedProfile ($path+'/profile') -CasePath ($path+'/case') -EnginePath $r.engine -ProjectPath $r.project -EvidencePath ($path+'/'+$phase)
        }
        $completed+=@{name=$name;row=$row}
        Write-Output ('CHAIN_PASS '+$completed.Count+'/'+$rows.Count+' '+$name)
        [IO.File]::WriteAllText((Join-Path $root 'progress.json'),(@{expected=$rows;completed=$completed}|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
    }
}catch{$failure=$_.Exception.Message}
[IO.File]::WriteAllText((Join-Path $root 'batch.json'),(@{ok=($failure -eq '');failure=$failure;matrix=$Matrix;expected=$rows;completed=$completed;project=$r.project;engine=$r.engine}|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
if($failure){throw $failure}
Write-Output ('MATRIX_PASS '+$completed.Count)
