extends SceneTree

var elapsed := 0.0
var frames := 0

func _initialize() -> void:
	change_scene_to_file.call_deferred("res://scenes/main/main.tscn")

func _process(delta: float) -> bool:
	elapsed += delta
	frames += 1
	if elapsed < 1.0: return false
	elapsed = 0.0
	var window := root
	var data := {"frames":frames, "window_size":str(window.size), "window_position":str(window.position), "mode":window.mode, "screen":window.current_screen, "visible_rect":str(window.get_visible_rect()), "content_scale_size":str(window.content_scale_size), "content_scale_factor":window.content_scale_factor, "screen_transform":str(window.get_screen_transform()), "canvas_transform":str(window.get_canvas_transform()), "nodes":[]}
	_capture(window, data.nodes)
	if root.has_node("SaveManager"): data.summaries = root.get_node("SaveManager").list_slot_summaries()
	var file := FileAccess.open("user://__layout_probe.json", FileAccess.WRITE)
	if file != null: file.store_string(JSON.stringify(data,"\t"))
	return false

func _capture(node: Node, rows: Array) -> void:
	if node is Control and (node.get_parent() is Window or String(node.name) in ["GGBMain", "Prologue", "ChapterOne", "InventoryPanel", "DialogueHUD", "DialogueHistory", "NotebookButton", "LocationLabel", "DialogueBacking"]):
		rows.append({"path":str(node.get_path()), "rect":str(node.get_global_rect()), "minimum":str(node.get_combined_minimum_size()), "scale":str(node.scale), "visible":node.is_visible_in_tree(), "anchors":[node.anchor_left,node.anchor_top,node.anchor_right,node.anchor_bottom], "offsets":[node.offset_left,node.offset_top,node.offset_right,node.offset_bottom]})
	for child in node.get_children(): _capture(child, rows)
