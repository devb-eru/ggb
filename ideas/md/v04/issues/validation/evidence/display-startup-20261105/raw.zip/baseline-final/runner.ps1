param([ValidateSet('default','windowed','borderless','fullscreen')][string]$Mode='default',[switch]$Overrides,[string]$Label='baseline')
$ErrorActionPreference='Stop'
$gui=Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-windows-sleep-20261105.json') -Raw|ConvertFrom-Json
$project=Join-Path $PSScriptRoot '.tmp-notebook-layout-candidate-20261105'
$root=Join-Path $env:TEMP ('ggb-display-startup-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root|Out-Null
$sources=@(Get-ChildItem (Join-Path $project 'scripts') -Recurse -File -Filter '*.gd'|ForEach-Object{@{path=[IO.Path]::GetRelativePath($project,$_.FullName).Replace('\','/');sha256=(Get-FileHash $_.FullName).Hash.ToLowerInvariant()}}|Sort-Object path)
Compress-Archive -LiteralPath (Join-Path $project 'scripts') -DestinationPath (Join-Path $root 'source_scripts.zip')
Copy-Item $PSCommandPath (Join-Path $root 'runner.ps1')
$oldApp=$env:APPDATA;$oldLocal=$env:LOCALAPPDATA;$p=$null
try{
    $env:APPDATA=Join-Path $root 'appdata';$env:LOCALAPPDATA=Join-Path $root 'localappdata'
    New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA|Out-Null
    $arguments=@('--path',('"'+$project+'"'))
    if($Overrides){$arguments+=@('--windowed','--resolution','1280x720','--position','100,100')}
    $arguments+=@('--','--display-startup-smoke')
    if($Mode -ne 'default'){$arguments+=('--display-startup-mode='+$Mode)}
    $out=Join-Path $root 'run.out.log';$err=Join-Path $root 'run.err.log';$start=[DateTime]::UtcNow.ToString('o')
    $p=Start-Process -FilePath $gui.engine -ArgumentList $arguments -WindowStyle Normal -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    $done=$false;$parse=$false
    for($i=0;$i -lt 180;$i++){
        if($p.WaitForExit(1000)){$done=$true;break}
        if((Get-Content $err -Raw) -match 'SCRIPT ERROR:|Parse Error:'){$parse=$true;break}
    }
    if(-not $done){$p.Kill();$p.WaitForExit()}
    $resultPath=Join-Path $env:APPDATA 'Godot/app_userdata/GGB/__test_display_startup_result.json'
    if(Test-Path $resultPath){Copy-Item $resultPath (Join-Path $root 'result.json')}
    $receipt=@{label=$Label;mode=$Mode;overrides=[bool]$Overrides;pid=$p.Id;completed=$done;parse_error=$parse;exit_code=$p.ExitCode;arguments=$arguments;started_utc=$start;finished_utc=[DateTime]::UtcNow.ToString('o');source_files=$sources;stdout_sha256=(Get-FileHash $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash $err).Hash.ToLowerInvariant();root=$root;engine_sha256=(Get-FileHash $gui.engine).Hash.ToLowerInvariant()}
    [IO.File]::WriteAllText((Join-Path $root 'run.json'),($receipt|ConvertTo-Json -Depth 8).Replace("`r`n","`n"),[Text.UTF8Encoding]::new($false))
    Add-Content -LiteralPath (Join-Path $PSScriptRoot '.tmp-notebook-layout-runs-20261105.txt') -Value $root
    @{root=$root;exit=$p.ExitCode;completed=$done;parse_error=$parse}|ConvertTo-Json
    Get-Content $err -Tail 20
    if(Test-Path $resultPath){$r=Get-Content $resultPath -Raw|ConvertFrom-Json;$r|Select-Object status,check_count,failures,final_window|ConvertTo-Json -Depth 5}
}finally{if($p -and -not $p.HasExited){$p.Kill();$p.WaitForExit()};$env:APPDATA=$oldApp;$env:LOCALAPPDATA=$oldLocal}
