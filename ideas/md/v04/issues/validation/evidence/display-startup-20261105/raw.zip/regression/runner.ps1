$ErrorActionPreference='Stop'
$gui=Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-windows-sleep-20261105.json') -Raw|ConvertFrom-Json
$project=Join-Path $PSScriptRoot '.tmp-notebook-layout-candidate-20261105'
$root=Join-Path $env:TEMP ('ggb-layout-regress-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root|Out-Null
$source=@(Get-ChildItem (Join-Path $project 'scripts') -Recurse -File -Filter '*.gd'|ForEach-Object{@{path=[IO.Path]::GetRelativePath($project,$_.FullName).Replace('\','/');sha256=(Get-FileHash $_.FullName).Hash.ToLowerInvariant()}}|Sort-Object path)
[IO.File]::WriteAllText((Join-Path $PSScriptRoot '.tmp-notebook-layout-regress-20261105.json'),(@{root=$root;project=$project;source_files=$source}|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
Copy-Item $PSCommandPath (Join-Path $root 'runner.ps1')
$oldApp=$env:APPDATA;$oldLocal=$env:LOCALAPPDATA
try{
    foreach($test in @('start-screen','full-campaign')){
        $env:APPDATA=Join-Path $root ($test+'/appdata');$env:LOCALAPPDATA=Join-Path $root ($test+'/localappdata')
        New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA -Force|Out-Null
        $out=Join-Path $root ($test+'.out.log');$err=Join-Path $root ($test+'.err.log')
        $args=@('--headless','--path',('"'+$project+'"'),'--',('--'+$test+'-smoke'),'--ggb-dev-full','--ggb-dev-notebook-v2','--notebook-require-authored')
        $p=Start-Process $gui.engine -ArgumentList $args -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
        $done=$false;$parse=$false
        for($i=0;$i -lt 900;$i++){
            if($p.WaitForExit(1000)){$done=$true;break}
            if((Get-Content $err -Raw) -match 'SCRIPT ERROR:|Parse Error:'){$parse=$true;break}
        }
        if(-not $done){$p.Kill();$p.WaitForExit()}
        $receipt=@{test=$test;completed=$done;parse_error=$parse;pid=$p.Id;exit_code=$p.ExitCode;source_files=$source;arguments=$args;stdout_sha256=(Get-FileHash $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash $err).Hash.ToLowerInvariant()}
        [IO.File]::WriteAllText((Join-Path $root ($test+'.json')),($receipt|ConvertTo-Json -Depth 6).Replace("`r`n","`n"),[Text.UTF8Encoding]::new($false))
        Get-Content $out -Tail 12;Get-Content $err -Tail 8
        if(-not $done -or $p.ExitCode -ne 0){throw ('Headless regression failed: '+$root)}
    }
    'LAYOUT_REGRESSION PASS'
}finally{$env:APPDATA=$oldApp;$env:LOCALAPPDATA=$oldLocal}
