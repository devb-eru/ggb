$ErrorActionPreference='Stop'
$r=Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-windows-sleep-20261105.json') -Raw|ConvertFrom-Json
$e=Join-Path $r.root 'late-modal-baseline'
if(Test-Path -LiteralPath $e){throw 'Baseline evidence already exists'}
New-Item -ItemType Directory -Path $e|Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $e 'runner.ps1')
$oldApp=$env:APPDATA;$oldLocal=$env:LOCALAPPDATA;$p=$null
try{
    $env:APPDATA=Join-Path $e 'appdata';$env:LOCALAPPDATA=Join-Path $e 'localappdata'
    New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA|Out-Null
    $arguments=@('--headless','--verbose','--path',('"'+$r.project+'"'),'--','--notebook-modal-presentation-smoke','--ggb-dev-notebook-v2','--notebook-require-authored')
    $out=Join-Path $e 'run.out.log';$err=Join-Path $e 'run.err.log'
    $started=[DateTime]::UtcNow.ToString('o')
    $p=Start-Process -FilePath $r.engine -ArgumentList $arguments -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    Write-Output ('LATE_MODAL_BASELINE PID='+$p.Id)
    $done=$p.WaitForExit(240000)
    if(-not $done){$p.Kill();$p.WaitForExit()}
    $receipt=@{completed=$done;exit_code=$p.ExitCode;pid=$p.Id;arguments=$arguments;head=$r.head;started_utc=$started;finished_utc=[DateTime]::UtcNow.ToString('o');engine_sha256=(Get-FileHash -LiteralPath $r.engine).Hash.ToLowerInvariant();runner_sha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash.ToLowerInvariant();stdout_sha256=(Get-FileHash -LiteralPath $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath $err).Hash.ToLowerInvariant();source_corpus=$r.source_corpus;data_corpus=$r.data_corpus;scope='baseline diagnosis, not Windows input or acceptance'}
    [IO.File]::WriteAllText((Join-Path $e 'run.json'),($receipt|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
    [pscustomobject]@{completed=$done;native=$p.ExitCode;evidence=$e}|ConvertTo-Json
    Get-Content -LiteralPath $err -Tail 25
    Get-Content -LiteralPath $out -Tail 5
}finally{if($null -ne $p -and -not $p.HasExited){$p.Kill();$p.WaitForExit()};$env:APPDATA=$oldApp;$env:LOCALAPPDATA=$oldLocal}
