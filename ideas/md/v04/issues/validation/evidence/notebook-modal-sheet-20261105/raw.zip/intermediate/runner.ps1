$ErrorActionPreference = 'Stop'
$r = Get-Content (Join-Path $PSScriptRoot '.tmp-notebook-windows-sleep-20261105.json') -Raw | ConvertFrom-Json
$root = Join-Path $env:TEMP ('ggb-modal-candidate-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root | Out-Null
$projectRoot = Join-Path $root 'source'
Expand-Archive -LiteralPath (Join-Path $r.root 'source.zip') -DestinationPath $projectRoot
$project = Join-Path $projectRoot 'game'
$relative = 'game/scripts/tests/notebook_modal_presentation_smoke.gd'
$edited = Join-Path $PSScriptRoot ('.tmp-notebook-sheet-20261103/' + $relative)
Copy-Item -LiteralPath $edited -Destination (Join-Path $projectRoot $relative)
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $root 'runner.ps1')
$meta = @{root=$root;project=$project;head=$r.head;engine=$r.engine;changed_file=$relative;changed_sha256=(Get-FileHash -LiteralPath $edited).Hash.ToLowerInvariant();scope='headless modal regression only; not Windows input acceptance'}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot '.tmp-notebook-late-modal-candidate-20261105.json'), ($meta|ConvertTo-Json), [Text.UTF8Encoding]::new($false))
$oldApp = $env:APPDATA; $oldLocal = $env:LOCALAPPDATA
$p = $null
try {
    $env:APPDATA = Join-Path $root 'appdata'; $env:LOCALAPPDATA = Join-Path $root 'localappdata'
    New-Item -ItemType Directory -Path $env:APPDATA,$env:LOCALAPPDATA | Out-Null
    foreach ($phase in @('import','seed','resume','completed')) {
        $argsList = @('--headless','--path',('"'+$project+'"'))
        if ($phase -eq 'import') { $argsList += @('--editor','--import') }
        else { $argsList += @('--','--notebook-modal-presentation-smoke','--ggb-dev-notebook-v2','--notebook-require-authored',('--cursor-phase='+$phase)) }
        $out = Join-Path $root ($phase+'.out.log'); $err = Join-Path $root ($phase+'.err.log')
        $started = [DateTime]::UtcNow.ToString('o')
        $p = Start-Process -FilePath $r.engine -ArgumentList $argsList -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
        Write-Output ($phase+' PID='+$p.Id)
        $done = $p.WaitForExit(240000)
        if (-not $done) { $p.Kill(); $p.WaitForExit() }
        $receipt = @{phase=$phase;completed=$done;exit_code=$p.ExitCode;pid=$p.Id;started_utc=$started;finished_utc=[DateTime]::UtcNow.ToString('o');arguments=$argsList;source=$meta;stdout_sha256=(Get-FileHash -LiteralPath $out).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath $err).Hash.ToLowerInvariant()}
        [IO.File]::WriteAllText((Join-Path $root ($phase+'.json')), ($receipt|ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
        Get-Content -LiteralPath $err -Tail 30
        Get-Content -LiteralPath $out -Tail 5
        if (-not $done -or $p.ExitCode -ne 0) { throw ('Failed phase: '+$phase+'; evidence: '+$root) }
    }
    Write-Output ('DONE '+$root)
} finally {
    if ($null -ne $p -and -not $p.HasExited) { $p.Kill(); $p.WaitForExit() }
    $env:APPDATA=$oldApp; $env:LOCALAPPDATA=$oldLocal
}
